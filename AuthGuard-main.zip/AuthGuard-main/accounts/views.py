from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.urls import reverse
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse, HttpResponseBadRequest
from django.contrib.auth.decorators import login_required

from .forms import SignUpForm, LoginForm
from .models import CustomUser
from .tokens import email_confirmation_token

def index_view(request):
    """
    Landing page. If user is authenticated, redirect to dashboard; otherwise show index.
    """
    if request.user.is_authenticated:
        return redirect("accounts:dashboard")
    return render(request, "accounts/base.html", {})  # base.html shows a 'Get Started' link

def signup_view(request):
    """
    Handle user registration. On POST:
      - Validate form
      - Create inactive user
      - Send confirmation email
    """
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            try:
                user = form.save(commit=False)
                user.save()
            except Exception as e:
                # Likely a ValidationError from model or DB constraint
                messages.error(request, f"Error creating user: {str(e)}")
                return render(request, "accounts/modal_auth.html", {
                    "signup_form": form,
                    "login_form": LoginForm(),
                    "show_modal": "signup",
                })

            # Generate email confirmation token
            try:
                uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
                token = email_confirmation_token.make_token(user)
                confirm_url = request.build_absolute_uri(
                    reverse("accounts:confirm_email", kwargs={"uidb64": uidb64, "token": token})
                )
                subject = "Confirm your Account"
                message = render_to_string("accounts/email/confirmation_email.html", {
                    "user": user,
                    "confirm_url": confirm_url,
                })
                send_mail(
                    subject,
                    message,
                    None,  # uses DEFAULT_FROM_EMAIL
                    [user.email],
                    fail_silently=False,
                )
            except BadHeaderError:
                user.delete()
                messages.error(request, "Invalid header found when sending confirmation email.")
                return render(request, "accounts/modal_auth.html", {
                    "signup_form": form,
                    "login_form": LoginForm(),
                    "show_modal": "signup",
                })
            except Exception as e:
                user.delete()
                messages.error(request, f"Failed to send confirmation email: {str(e)}")
                return render(request, "accounts/modal_auth.html", {
                    "signup_form": form,
                    "login_form": LoginForm(),
                    "show_modal": "signup",
                })

            # Success: Show a “check your inbox” page
            return render(request, "accounts/email_confirmed.html", {
                "email": user.email,
                "new": True
            })
        else:
            # Form is invalid
            return render(request, "accounts/modal_auth.html", {
                "signup_form": form,
                "login_form": LoginForm(),
                "show_modal": "signup",
            })
    else:
        form = SignUpForm()
    return render(request, "accounts/modal_auth.html", {
        "signup_form": form,
        "login_form": LoginForm(),
        "show_modal": "signup",
    })

def login_view(request):
    """
    Handle user login. On POST:
      - Validate form
      - Authenticate user
      - Check is_active
    """
    if request.method == "POST":
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            email = form.cleaned_data.get("username").lower()
            password = form.cleaned_data.get("password")
            user = authenticate(request, email=email, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return redirect("accounts:dashboard")
                else:
                    messages.error(request, "Account not activated. Please check your email.")
            else:
                messages.error(request, "Invalid email or password.")
        # If form invalid or authentication failed, re-render modal with errors
        return render(request, "accounts/modal_auth.html", {
            "login_form": form,
            "signup_form": SignUpForm(),
            "show_modal": "login",
        })
    else:
        form = LoginForm()
    return render(request, "accounts/modal_auth.html", {
        "login_form": form,
        "signup_form": SignUpForm(),
        "show_modal": "login",
    })

def confirm_email_view(request, uidb64, token):
    """
    Activate the user's account if the confirmation link is valid.
    """
    try:
        # Decode UID, get user
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = CustomUser.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, CustomUser.DoesNotExist):
        user = None

    if user is not None and email_confirmation_token.check_token(user, token):
        user.is_active = True
        user.save()
        return render(request, "accounts/email_confirmed.html", {
            "email": user.email,
            "confirmed": True
        })
    else:
        return HttpResponseBadRequest("Invalid or expired confirmation link.")

@login_required
def dashboard_view(request):
    """
    Simple dashboard that only an authenticated user can see.
    """
    return render(request, "accounts/dashboard.html", {
        "user": request.user
    })
