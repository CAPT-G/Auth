from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils import timezone
from django.core.exceptions import ValidationError

class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, display_name=None, **extra_fields):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError("The Email field must be set.")
        email = self.normalize_email(email)
        if not display_name:
            display_name = email.split('@')[0].lower()

        # Ensure display_name is unique
        if CustomUser.objects.filter(display_name=display_name).exists():
            raise ValidationError("This display name is already taken.")

        user = self.model(email=email, display_name=display_name, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, display_name=None, **extra_fields):
        """
        Creates and saves a superuser with the given email and password.
        """
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")
        return self.create_user(email, password, display_name, **extra_fields)

class CustomUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    display_name = models.CharField(max_length=32, unique=True)
    is_active = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []  # Email & password are required by default.

    objects = CustomUserManager()

    def save(self, *args, **kwargs):
        # If no display_name was provided, derive from email
        if not self.display_name:
            self.display_name = self.email.split('@')[0].lower()

        # Ensure uniqueness of display_name
        if CustomUser.objects.exclude(pk=self.pk).filter(display_name=self.display_name).exists():
            raise ValidationError("Display name '%s' is already taken." % self.display_name)

        super().save(*args, **kwargs)

    def __str__(self):
        return self.email
