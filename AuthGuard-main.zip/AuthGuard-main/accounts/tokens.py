from django.contrib.auth.tokens import PasswordResetTokenGenerator
import six

class EmailConfirmationTokenGenerator(PasswordResetTokenGenerator):
    """
    Generates a token for email confirmation, based on the same algorithm as PasswordResetTokenGenerator,
    but separate for clarity.
    """
    def _make_hash_value(self, user, timestamp):
        return (
            six.text_type(user.pk)
            + six.text_type(timestamp)
            + six.text_type(user.is_active)
        )

email_confirmation_token = EmailConfirmationTokenGenerator()

